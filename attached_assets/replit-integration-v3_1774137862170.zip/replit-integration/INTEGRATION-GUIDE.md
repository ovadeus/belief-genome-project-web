# Belief Genome — Replit Integration Guide

## File Placement

Copy these files into your existing Replit monorepo:

```
replit-integration/
├── lib/
│   ├── db/src/schema/users.ts          → lib/db/src/schema/users.ts
│   └── belief-engine/src/              → lib/belief-engine/src/
│       ├── index.ts
│       ├── beliefDNA.ts
│       ├── dnaCalculator.ts
│       ├── probeBank.ts
│       └── probeFeeds.ts
├── artifacts/
│   ├── api-server/src/routes/
│   │   ├── genome-auth.ts              → artifacts/api-server/src/routes/genome-auth.ts
│   │   ├── genome-probes.ts            → artifacts/api-server/src/routes/genome-probes.ts
│   │   └── genome-data.ts              → artifacts/api-server/src/routes/genome-data.ts
│   └── whoo-ru/src/
│       ├── components/genome/
│       │   ├── GenomeAuthContext.tsx    → artifacts/whoo-ru/src/components/genome/
│       │   ├── GenomeNav.tsx           (global nav bar for signed-in users)
│       │   ├── GenomeLayout.tsx        (layout wrapper with nav + auth guard)
│       │   ├── RadarChart.tsx          (9-axis world view radar)
│       │   ├── BreakdownBars.tsx       (category spectrum bars with labels)
│       │   ├── TripleHelix.tsx         (Logos/Pathos/Ethos DNA helix viz)
│       │   ├── Timeline.tsx            (belief drift over time chart)
│       │   ├── Forecaster.tsx          (AI belief trajectory predictions)
│       │   ├── DnaString.tsx           (135-char color-coded display)
│       │   └── HistoryList.tsx         (scrollable response log)
│       └── pages/genome/
│           ├── ProbePage.tsx            → artifacts/whoo-ru/src/pages/genome/
│           ├── DashboardPage.tsx       (6-tab dashboard: Triple Helix, Radar, Breakdown, Timeline, History, Forecaster)
│           ├── DnaPage.tsx             (dedicated DNA string viewer)
│           ├── ProfilePage.tsx         (name, gender, DOB, country, zip, DNA prefix)
│           ├── LoginPage.tsx
│           └── RegisterPage.tsx
```

---

## Step 1: Database Schema

Add `users.ts` to `lib/db/src/schema/`. Then add to your schema index:

```ts
// lib/db/src/schema/index.ts — add this line:
export * from './users';
```

Run migration:
```bash
pnpm --filter db drizzle-kit generate
pnpm --filter db drizzle-kit migrate
```

---

## Step 2: Belief Engine Package

Add `lib/belief-engine/` as a workspace package.

Create `lib/belief-engine/package.json`:
```json
{
  "name": "@belief-genome/engine",
  "version": "1.0.0",
  "main": "src/index.ts",
  "types": "src/index.ts"
}
```

Add to `pnpm-workspace.yaml`:
```yaml
packages:
  - 'lib/*'
  - 'artifacts/*'
  - 'packages/*'
```

Then add it as a dependency to `api-server` and `whoo-ru`:
```bash
pnpm --filter api-server add @belief-genome/engine@workspace:*
pnpm --filter whoo-ru add @belief-genome/engine@workspace:*
```

---

## Step 3: Install Dependencies

```bash
# Backend
pnpm --filter api-server add bcryptjs jsonwebtoken
pnpm --filter api-server add -D @types/bcryptjs @types/jsonwebtoken

# Frontend (for radar chart)
pnpm --filter whoo-ru add chart.js react-chartjs-2
```

---

## Step 4: Mount API Routes

In your main Express server file (e.g., `artifacts/api-server/src/index.ts`):

```ts
import genomeAuthRouter from './routes/genome-auth';
import genomeProbesRouter from './routes/genome-probes';
import genomeDataRouter from './routes/genome-data';
import { genomeAuth } from './routes/genome-auth';
import cookieParser from 'cookie-parser';

// Add cookie parser if not already present
app.use(cookieParser());

// Public routes (login, register)
app.use('/api/genome', genomeAuthRouter);

// Protected routes (require genome user auth)
app.use('/api/genome', genomeAuth, genomeDataRouter);
app.use('/api/genome/probes', genomeAuth, genomeProbesRouter);
```

Set `GENOME_JWT_SECRET` in your `.env`:
```
GENOME_JWT_SECRET=your-secret-here
OPENAI_API_KEY=sk-...  # for AI news probe generation (optional)
```

---

## Step 5: Frontend Routes (with GenomeLayout)

In your existing `App.tsx` (wouter router), add the genome routes.
Use `GenomeLayout` to wrap all genome pages — it provides the global nav bar
and handles auth redirect automatically.

```tsx
import { Route, Switch } from 'wouter';
import { GenomeAuthProvider } from './components/genome/GenomeAuthContext';
import GenomeLayout from './components/genome/GenomeLayout';
import LoginPage from './pages/genome/LoginPage';
import RegisterPage from './pages/genome/RegisterPage';
import ProbePage from './pages/genome/ProbePage';
import DashboardPage from './pages/genome/DashboardPage';
import DnaPage from './pages/genome/DnaPage';
import ProfilePage from './pages/genome/ProfilePage';

// Inside your App component:
<GenomeAuthProvider>
  <Switch>
    {/* ...existing routes... */}

    {/* All genome routes use GenomeLayout (handles nav + auth guard) */}
    <Route path="/genome/login">
      <GenomeLayout><LoginPage /></GenomeLayout>
    </Route>
    <Route path="/genome/register">
      <GenomeLayout><RegisterPage /></GenomeLayout>
    </Route>
    <Route path="/genome/probe">
      <GenomeLayout><ProbePage /></GenomeLayout>
    </Route>
    <Route path="/genome/dashboard">
      <GenomeLayout><DashboardPage /></GenomeLayout>
    </Route>
    <Route path="/genome/dna">
      <GenomeLayout><DnaPage /></GenomeLayout>
    </Route>
    <Route path="/genome/profile">
      <GenomeLayout><ProfilePage /></GenomeLayout>
    </Route>
  </Switch>
</GenomeAuthProvider>
```

**GenomeLayout** automatically:
- Shows the global nav bar (Probe | Genome Analytics | Belief DNA | Profile | Sign Out)
- Hides nav on login/register pages
- Redirects unauthenticated users to `/genome/login`

---

## Step 6: Global Navigation

Once signed in, users see a sticky nav bar at the top with:

| Link | Path | Description |
|------|------|-------------|
| Probe | `/genome/probe` | Answer belief probes (slider, semantic labels) |
| Genome Analytics | `/genome/dashboard` | 6-tab dashboard (Triple Helix, Radar, Breakdown, Timeline, History, Forecaster) |
| Belief DNA | `/genome/dna` | Full 135-char DNA string viewer with copy + legend |
| Profile | `/genome/profile` | Edit name, gender, DOB, country (dropdown), zip, live DNA prefix preview |
| Sign Out | — | Clears JWT and redirects to login |

---

## Step 7: Add Login Button to Homepage (Top Right)

To add a login/register button to the top-right of your existing home page,
add a genome auth button to your existing Navbar or header component.

### Option A: Standalone button (add to any header)

```tsx
import { useGenomeAuth } from '../components/genome/GenomeAuthContext';
import { useLocation } from 'wouter';

function GenomeAuthButton() {
  const { user, logout } = useGenomeAuth();
  const [, setLocation] = useLocation();

  if (user) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <a href="/genome/dashboard"
          onClick={e => { e.preventDefault(); setLocation('/genome/dashboard'); }}
          style={{ color: '#6c8fff', fontSize: 13, textDecoration: 'none' }}>
          Dashboard
        </a>
        <span style={{ color: 'rgba(255,255,255,0.3)' }}>|</span>
        <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{user.name}</span>
        <button onClick={logout} style={{
          padding: '6px 14px', borderRadius: 6, border: '1px solid rgba(255,255,255,0.15)',
          background: 'transparent', color: 'rgba(255,255,255,0.5)', fontSize: 12, cursor: 'pointer',
        }}>
          Sign Out
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <a href="/genome/login"
        onClick={e => { e.preventDefault(); setLocation('/genome/login'); }}
        style={{
          padding: '6px 16px', borderRadius: 6, border: '1px solid rgba(108,143,255,0.3)',
          color: '#6c8fff', fontSize: 13, textDecoration: 'none',
        }}>
        Sign In
      </a>
      <a href="/genome/register"
        onClick={e => { e.preventDefault(); setLocation('/genome/register'); }}
        style={{
          padding: '6px 16px', borderRadius: 6, border: 'none',
          background: '#6c8fff', color: '#fff', fontSize: 13, textDecoration: 'none',
        }}>
        Get Started
      </a>
    </div>
  );
}
```

### Option B: Add to existing Navbar

Find your existing Navbar/Header component and add `<GenomeAuthButton />` to
the right side. Make sure the parent component is inside `<GenomeAuthProvider>`.

---

## Architecture Summary

- **Auth**: Genome users have their own `users` table and JWT tokens, completely separate from admin auth
- **All API routes**: prefixed with `/api/genome` to avoid conflicts with existing `/claude-api` routes
- **All frontend pages**: prefixed with `/genome/` in the URL
- **Global nav**: `GenomeNav` component (inside `GenomeLayout`) — sticky bar with all user-facing links
- **Domain logic**: in `@belief-genome/engine` package, shared between backend and frontend
- **Dashboard**: 6 visualization tabs — Triple Helix, Radar, Breakdown, Timeline, History, Forecaster
- **Profile**: Editable name, gender, DOB, country (55-country dropdown), zip code, live DNA prefix
- **No API keys needed**: Users don't store any API keys. Only `OPENAI_API_KEY` on the server for news probe AI classification
