# Belief Genome — Replit Integration Guide

## File Placement

Copy these files into your existing Replit monorepo:

```
replit-integration/
├── lib/
│   ├── db/src/schema/users.ts          → lib/db/src/schema/users.ts
│   └── belief-engine/src/              → lib/belief-engine/src/
│       ├── index.ts
│       ├── beliefDNA.ts
│       ├── dnaCalculator.ts
│       ├── probeBank.ts
│       └── probeFeeds.ts
├── artifacts/
│   ├── api-server/src/routes/
│   │   ├── genome-auth.ts              → artifacts/api-server/src/routes/genome-auth.ts
│   │   ├── genome-probes.ts            → artifacts/api-server/src/routes/genome-probes.ts
│   │   └── genome-data.ts              → artifacts/api-server/src/routes/genome-data.ts
│   └── whoo-ru/src/
│       ├── components/genome/
│       │   ├── GenomeAuthContext.tsx    → artifacts/whoo-ru/src/components/genome/
│       │   ├── RadarChart.tsx
│       │   ├── BreakdownBars.tsx
│       │   ├── DnaString.tsx
│       │   └── HistoryList.tsx
│       └── pages/genome/
│           ├── ProbePage.tsx            → artifacts/whoo-ru/src/pages/genome/
│           ├── DashboardPage.tsx
│           ├── ProfilePage.tsx
│           ├── LoginPage.tsx
│           └── RegisterPage.tsx
```

---

## Step 1: Database Schema

Add `users.ts` to `lib/db/src/schema/`. Then add to your schema index:

```ts
// lib/db/src/schema/index.ts — add this line:
export * from './users';
```

Run migration:
```bash
pnpm --filter db drizzle-kit generate
pnpm --filter db drizzle-kit migrate
```

---

## Step 2: Belief Engine Package

Add `lib/belief-engine/` as a workspace package.

Create `lib/belief-engine/package.json`:
```json
{
  "name": "@belief-genome/engine",
  "version": "1.0.0",
  "main": "src/index.ts",
  "types": "src/index.ts"
}
```

Add to `pnpm-workspace.yaml`:
```yaml
packages:
  - 'lib/*'
  - 'artifacts/*'
  - 'packages/*'
```

Then add it as a dependency to `api-server` and `whoo-ru`:
```bash
pnpm --filter api-server add @belief-genome/engine@workspace:*
pnpm --filter whoo-ru add @belief-genome/engine@workspace:*
```

---

## Step 3: Install Dependencies

```bash
# Backend
pnpm --filter api-server add bcryptjs jsonwebtoken
pnpm --filter api-server add -D @types/bcryptjs @types/jsonwebtoken

# Frontend (for radar chart)
pnpm --filter whoo-ru add chart.js react-chartjs-2
```

---

## Step 4: Mount API Routes

In your main Express server file (e.g., `artifacts/api-server/src/index.ts`):

```ts
import genomeAuthRouter from './routes/genome-auth';
import genomeProbesRouter from './routes/genome-probes';
import genomeDataRouter from './routes/genome-data';
import { genomeAuth } from './routes/genome-auth';
import cookieParser from 'cookie-parser';

// Add cookie parser if not already present
app.use(cookieParser());

// Public routes (login, register)
app.use('/api/genome', genomeAuthRouter);

// Protected routes (require genome user auth)
app.use('/api/genome', genomeAuth, genomeDataRouter);
app.use('/api/genome/probes', genomeAuth, genomeProbesRouter);
```

Set `GENOME_JWT_SECRET` in your `.env`:
```
GENOME_JWT_SECRET=your-secret-here
OPENAI_API_KEY=sk-...  # for AI news probe generation
```

---

## Step 5: Frontend Routes

In your existing `App.tsx` (wouter router), add the genome routes:

```tsx
import { Route, Switch } from 'wouter';
import { GenomeAuthProvider, useGenomeAuth } from './components/genome/GenomeAuthContext';
import LoginPage from './pages/genome/LoginPage';
import RegisterPage from './pages/genome/RegisterPage';
import ProbePage from './pages/genome/ProbePage';
import DashboardPage from './pages/genome/DashboardPage';
import ProfilePage from './pages/genome/ProfilePage';

// Protected route wrapper
function GenomeProtected({ children }: { children: React.ReactNode }) {
  const { user, loading } = useGenomeAuth();
  const [, setLocation] = useLocation();
  if (loading) return <div>Loading...</div>;
  if (!user) { setLocation('/genome/login'); return null; }
  return <>{children}</>;
}

// Inside your App component, wrap genome routes in GenomeAuthProvider:
<GenomeAuthProvider>
  <Switch>
    {/* ...existing routes... */}

    {/* Genome public routes */}
    <Route path="/genome/login" component={LoginPage} />
    <Route path="/genome/register" component={RegisterPage} />

    {/* Genome protected routes */}
    <Route path="/genome/probe">
      <GenomeProtected><ProbePage /></GenomeProtected>
    </Route>
    <Route path="/genome/dashboard">
      <GenomeProtected><DashboardPage /></GenomeProtected>
    </Route>
    <Route path="/genome/profile">
      <GenomeProtected><ProfilePage /></GenomeProtected>
    </Route>
  </Switch>
</GenomeAuthProvider>
```

---

## Step 6: Add Login Button to Homepage (Top Right)

To add a login/register button to the top-right of your existing home page,
add a genome auth button to your existing Navbar or header component.

### Option A: Standalone button (add to any header)

```tsx
import { useGenomeAuth } from '../components/genome/GenomeAuthContext';
import { useLocation } from 'wouter';

function GenomeAuthButton() {
  const { user, logout } = useGenomeAuth();
  const [, setLocation] = useLocation();

  if (user) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <a href="/genome/dashboard"
          onClick={e => { e.preventDefault(); setLocation('/genome/dashboard'); }}
          style={{ color: '#6c8fff', fontSize: 13, textDecoration: 'none' }}>
          Dashboard
        </a>
        <span style={{ color: 'rgba(255,255,255,0.3)' }}>|</span>
        <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{user.name}</span>
        <button onClick={logout} style={{
          padding: '6px 14px', borderRadius: 6, border: '1px solid rgba(255,255,255,0.15)',
          background: 'transparent', color: 'rgba(255,255,255,0.5)', fontSize: 12, cursor: 'pointer',
        }}>
          Sign Out
        </button>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', gap: 8 }}>
      <a href="/genome/login"
        onClick={e => { e.preventDefault(); setLocation('/genome/login'); }}
        style={{
          padding: '6px 16px', borderRadius: 6, border: '1px solid rgba(108,143,255,0.3)',
          color: '#6c8fff', fontSize: 13, textDecoration: 'none',
        }}>
        Sign In
      </a>
      <a href="/genome/register"
        onClick={e => { e.preventDefault(); setLocation('/genome/register'); }}
        style={{
          padding: '6px 16px', borderRadius: 6, border: 'none',
          background: '#6c8fff', color: '#fff', fontSize: 13, textDecoration: 'none',
        }}>
        Get Started
      </a>
    </div>
  );
}
```

### Option B: Add to existing Navbar

Find your existing Navbar/Header component and add `<GenomeAuthButton />` to
the right side. Make sure the parent component is inside `<GenomeAuthProvider>`.

Example:
```tsx
<nav style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 24px' }}>
  <div>{/* your existing logo/links */}</div>
  <GenomeAuthButton />
</nav>
```

---

## Architecture Summary

- **Auth**: Genome users have their own `users` table and JWT tokens, completely separate from admin auth
- **All routes**: prefixed with `/api/genome` to avoid conflicts with existing `/claude-api` routes
- **All pages**: prefixed with `/genome/` in the URL
- **Domain logic**: in `@belief-genome/engine` package, shared between backend and frontend
- **No API keys needed**: Users don't store any API keys. Only `OPENAI_API_KEY` on the server for news probe AI classification
